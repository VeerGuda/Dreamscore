import React from 'react';

import VectorImage from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector1Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector2Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector3Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector4Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector5Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector6Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector7Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector8Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector9Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector10Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector11Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector12Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Vector13Image from 'src/assets/images/DreamScoreMainpage_Vector.png';

import Ellipse3Image from 'src/assets/images/DreamScoreMainpage_Ellipse_3.png';

import Ellipse4Image from 'src/assets/images/DreamScoreMainpage_Ellipse_4.png';

import Ellipse5Image from 'src/assets/images/DreamScoreMainpage_Ellipse_5.png';

import {
  styled
} from '@mui/material/styles';

import Header from 'src/components/Header/Header';

import Navigation from 'src/components/Navigation/Navigation';

const DreamScoreMainPage1 = styled("div")({
  backgroundColor: `rgba(22, 22, 34, 1)`,
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  width: `428px`,
  height: `845px`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
});

const Frame6699 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `column`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `369px`,
  left: `30px`,
  top: `646px`,
  height: `313px`,
});

const Group6698 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  height: `28px`,
  width: `145px`,
  margin: `0px`,
});

const WeeklyOverview = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `600`,
  fontSize: `19px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Group6695 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  height: `81px`,
  width: `369px`,
  margin: `14px 0px 0px 0px`,
});

const Rectangle24 = styled("div")({
  backgroundColor: `rgba(30, 32, 59, 1)`,
  boxShadow: `1px 5px 40px rgba(110, 117, 136, 0.07)`,
  borderRadius: `10px`,
  width: `369px`,
  height: `81px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Frame6681 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `center`,
  padding: `0px`,
  boxSizing: `border-box`,
  left: `21px`,
  top: `15px`,
  height: `49.71px`,
  width: `325.38px`,
});

const Frame7826 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `50.38px`,
  height: `49.71px`,
  margin: `0px`,
});

const Rectangle25 = styled("div")({
  backgroundColor: `rgba(255, 232, 232, 1)`,
  borderRadius: `5px`,
  width: `50.38px`,
  height: `49.71px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Group7795 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `22px`,
  height: `22.01px`,
  left: `13px`,
  top: `14px`,
});

const Group7820 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `22px`,
  height: `22.01px`,
  left: `0px`,
  top: `0px`,
});

const Vector = styled("img")({
  height: `13.44px`,
  width: `3.89px`,
  position: `absolute`,
  left: `17px`,
  top: `9px`,
});

const Vector1 = styled("img")({
  height: `10.19px`,
  width: `3.89px`,
  position: `absolute`,
  left: `9px`,
  top: `12px`,
});

const Vector2 = styled("img")({
  height: `6.94px`,
  width: `3.89px`,
  position: `absolute`,
  left: `2px`,
  top: `15px`,
});

const Vector3 = styled("img")({
  height: `0px`,
  width: `22px`,
  position: `absolute`,
  left: `0px`,
  top: `22px`,
});

const Vector4 = styled("img")({
  height: `4.55px`,
  width: `18.08px`,
  position: `absolute`,
  left: `1px`,
  top: `2px`,
});

const Vector5 = styled("img")({
  height: `5.63px`,
  width: `3.2px`,
  position: `absolute`,
  left: `17px`,
  top: `0px`,
});

const Group6680 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `260px`,
  height: `49px`,
  margin: `0px 0px 0px 15px`,
});

const Group6052 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `84px`,
  height: `49px`,
  left: `0px`,
  top: `0px`,
});

const Investing = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `500`,
  fontSize: `16px`,
  letterSpacing: `-0.32px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Q24Increase = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(164, 169, 174, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `600`,
  fontSize: `14px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `0px`,
  top: `28px`,
});

const Q82 = styled("div")({
  textAlign: `right`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `500`,
  fontSize: `20px`,
  letterSpacing: `1.2px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `220px`,
  top: `10px`,
});

const Group6699 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  height: `81px`,
  width: `369px`,
  margin: `14px 0px 0px 0px`,
});

const Rectangle241 = styled("div")({
  backgroundColor: `rgba(30, 32, 59, 1)`,
  boxShadow: `1px 5px 40px rgba(110, 117, 136, 0.07)`,
  borderRadius: `10px`,
  width: `369px`,
  height: `81px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Frame66811 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `center`,
  padding: `0px`,
  boxSizing: `border-box`,
  left: `21px`,
  top: `15px`,
  height: `49.71px`,
  width: `325.38px`,
});

const Frame78261 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `50.38px`,
  height: `49.71px`,
  margin: `0px`,
});

const Rectangle251 = styled("div")({
  backgroundColor: `rgba(227, 233, 255, 1)`,
  borderRadius: `5px`,
  width: `50.38px`,
  height: `49.71px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Group77951 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `21.35px`,
  height: `21.97px`,
  left: `14px`,
  top: `14px`,
});

const Vector6 = styled("img")({
  height: `7.76px`,
  width: `5.56px`,
  position: `absolute`,
  left: `8px`,
  top: `9px`,
});

const Vector7 = styled("img")({
  height: `10px`,
  width: `0px`,
  position: `absolute`,
  left: `11px`,
  top: `8px`,
});

const Vector8 = styled("img")({
  height: `4.46px`,
  width: `8.93px`,
  position: `absolute`,
  left: `6px`,
  top: `0px`,
});

const Vector9 = styled("img")({
  height: `17.81px`,
  width: `21.35px`,
  position: `absolute`,
  left: `0px`,
  top: `4px`,
});

const Group66801 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `260px`,
  height: `49px`,
  margin: `0px 0px 0px 15px`,
});

const Group60521 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `89px`,
  height: `49px`,
  left: `0px`,
  top: `0px`,
});

const Saving = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `500`,
  fontSize: `16px`,
  letterSpacing: `-0.32px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Q12Decrease = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(164, 169, 174, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `600`,
  fontSize: `14px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `0px`,
  top: `28px`,
});

const Q52 = styled("div")({
  textAlign: `right`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `500`,
  fontSize: `20px`,
  letterSpacing: `1.2px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `220px`,
  top: `10px`,
});

const Group6700 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  height: `81px`,
  width: `369px`,
  margin: `14px 0px 0px 0px`,
});

const Rectangle242 = styled("div")({
  backgroundColor: `rgba(30, 32, 59, 1)`,
  boxShadow: `1px 5px 40px rgba(110, 117, 136, 0.07)`,
  borderRadius: `10px`,
  width: `369px`,
  height: `81px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Frame66812 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `center`,
  padding: `0px`,
  boxSizing: `border-box`,
  left: `21px`,
  top: `15px`,
  height: `49.71px`,
  width: `325.38px`,
});

const Frame78262 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `50.38px`,
  height: `49.71px`,
  margin: `0px`,
});

const Rectangle252 = styled("div")({
  backgroundColor: `rgba(254, 247, 228, 1)`,
  borderRadius: `5px`,
  width: `50.38px`,
  height: `49.71px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Group77952 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `22px`,
  height: `22.05px`,
  left: `13px`,
  top: `14px`,
});

const Group7809 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `22px`,
  height: `22.05px`,
  left: `0px`,
  top: `0px`,
});

const Vector10 = styled("img")({
  height: `22.01px`,
  width: `20.31px`,
  position: `absolute`,
  left: `2px`,
  top: `0px`,
});

const Vector11 = styled("img")({
  height: `11.32px`,
  width: `4.21px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Vector12 = styled("img")({
  height: `6.95px`,
  width: `5.02px`,
  position: `absolute`,
  left: `11px`,
  top: `7px`,
});

const Vector13 = styled("img")({
  height: `9px`,
  width: `0px`,
  position: `absolute`,
  left: `13px`,
  top: `6px`,
});

const Group66802 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `260px`,
  height: `49px`,
  margin: `0px 0px 0px 15px`,
});

const Group60522 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `81px`,
  height: `49px`,
  left: `0px`,
  top: `0px`,
});

const Budgeting = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `500`,
  fontSize: `16px`,
  letterSpacing: `-0.32px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Q7Decrease = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(164, 169, 174, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `600`,
  fontSize: `14px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `0px`,
  top: `28px`,
});

const Q12 = styled("div")({
  textAlign: `right`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `500`,
  fontSize: `20px`,
  letterSpacing: `1.2px`,
  textDecoration: `none`,
  lineHeight: `146.5000033378601%`,
  textTransform: `none`,
  position: `absolute`,
  left: `220px`,
  top: `10px`,
});

const Frame16 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `center`,
  padding: `0px`,
  boxSizing: `border-box`,
  left: `50px`,
  top: `106px`,
  height: `38px`,
  width: `328px`,
});

const Frame15 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `160px`,
  height: `38px`,
  margin: `0px`,
});

const Rectangle10 = styled("div")({
  backgroundColor: `rgba(69, 110, 254, 1)`,
  borderRadius: `20px`,
  width: `160px`,
  height: `38px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const DreamScore = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Inter`,
  fontWeight: `600`,
  fontSize: `13px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  position: `absolute`,
  left: `41px`,
  top: `11px`,
});

const Frame14 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `160px`,
  height: `38px`,
  margin: `0px 0px 0px 8px`,
});

const Rectangle11 = styled("div")({
  backgroundColor: `rgba(248, 248, 248, 1)`,
  borderRadius: `20px`,
  width: `160px`,
  height: `38px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Review = styled("div")({
  textAlign: `center`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(64, 64, 64, 1)`,
  fontStyle: `normal`,
  fontFamily: `Inter`,
  fontWeight: `400`,
  fontSize: `13px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  position: `absolute`,
  left: `58px`,
  top: `11px`,
});

const Frame6700 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `column`,
  justifyContent: `flex-start`,
  alignItems: `center`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `186px`,
  left: `121px`,
  top: `215px`,
  height: `289.99px`,
});

const Frame20 = styled("div")({
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  alignSelf: `stretch`,
  height: `169px`,
  margin: `0px`,
  width: `186px`,
});

const Frame19 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `186px`,
  height: `186px`,
  left: `0px`,
  top: `0px`,
});

const Ellipse3 = styled("img")({
  height: `186px`,
  width: `186px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Ellipse4 = styled("img")({
  height: `186px`,
  width: `186px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Ellipse5 = styled("img")({
  height: `186px`,
  width: `186px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Q81 = styled("div")({
  textAlign: `center`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Inter`,
  fontWeight: `700`,
  fontSize: `60px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  width: `73px`,
  height: `72px`,
  position: `absolute`,
  left: `57px`,
  top: `48px`,
});

const Q7 = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(19, 201, 153, 1)`,
  fontStyle: `normal`,
  fontFamily: `Inter`,
  fontWeight: `700`,
  fontSize: `20px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  position: `absolute`,
  left: `81px`,
  top: `120px`,
});

const Frame18 = styled("div")({
  backgroundColor: `rgba(220, 247, 240, 1)`,
  borderRadius: `10px`,
  display: `flex`,
  position: `relative`,
  isolation: `isolate`,
  flexDirection: `column`,
  justifyContent: `flex-start`,
  alignItems: `center`,
  padding: `16px 24px`,
  boxSizing: `border-box`,
  width: `149px`,
  margin: `16px 0px 0px 0px`,
  height: `69.99px`,
});

const YourDreamscore = styled("div")({
  textAlign: `center`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(35, 48, 59, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `500`,
  fontSize: `11px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  alignSelf: `stretch`,
  margin: `0px`,
});

const Great = styled("div")({
  textAlign: `center`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(19, 201, 153, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `600`,
  fontSize: `20px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  alignSelf: `stretch`,
  height: `19.99px`,
  margin: `5px 0px 0px 0px`,
});

const WhatIsDreamscore = styled("div")({
  textAlign: `center`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(69, 110, 254, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `500`,
  fontSize: `16px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  alignSelf: `stretch`,
  margin: `16px 0px 0px 0px`,
});

const GoalProgress = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(255, 255, 255, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `600`,
  fontSize: `20px`,
  letterSpacing: `-0.6px`,
  textDecoration: `none`,
  textTransform: `none`,
  position: `absolute`,
  left: `30px`,
  top: `528px`,
});

const Frame7834 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `369px`,
  height: `53px`,
  left: `30px`,
  top: `575px`,
});

const ProgressBarW75 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  alignSelf: `stretch`,
  width: `369px`,
  left: `0px`,
  top: `0px`,
  height: `10.14px`,
});

const Background = styled("div")({
  backgroundColor: `rgba(237, 242, 247, 1)`,
  borderRadius: `42.22972869873047px`,
  width: `369px`,
  height: `10.14px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const ProgressBarW751 = styled("div")({
  backgroundColor: `rgba(19, 201, 153, 1)`,
  borderRadius: `42.22972869873047px`,
  width: `276.75px`,
  height: `10.14px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Frame7833 = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `172px`,
  height: `38px`,
  left: `197px`,
  top: `15px`,
});

const Q80 = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(19, 201, 153, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `700`,
  fontSize: `32px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  width: `65px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Progress = styled("div")({
  display: `flex`,
  position: `absolute`,
  isolation: `isolate`,
  flexDirection: `row`,
  justifyContent: `flex-start`,
  alignItems: `flex-start`,
  padding: `0px`,
  boxSizing: `border-box`,
  width: `102px`,
  height: `16px`,
  left: `70px`,
  top: `10px`,
});

const Q119 = styled("div")({
  textAlign: `left`,
  whiteSpace: `pre-wrap`,
  fontSynthesis: `none`,
  color: `rgba(248, 248, 248, 1)`,
  fontStyle: `normal`,
  fontFamily: `Roboto`,
  fontWeight: `400`,
  fontSize: `14px`,
  letterSpacing: `0px`,
  textDecoration: `none`,
  textTransform: `none`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Header = styled(Header)({
  width: `428px`,
  position: `absolute`,
  left: `0px`,
  top: `0px`,
});

const Navigation = styled(Navigation)({
  width: `428px`,
  height: `100px`,
  position: `absolute`,
  left: `0px`,
  top: `745px`,
});


function DreamScoreMainPage() {
  return (
    <DreamScoreMainPage1>
      <Frame6699>
        <Group6698>
          <WeeklyOverview>
            {`Weekly Overview`}
          </WeeklyOverview>
        </Group6698>
        <Group6695>
          <Rectangle24>
          </Rectangle24>
          <Frame6681>
            <Frame7826>
              <Rectangle25>
              </Rectangle25>
              <Group7795>
                <Group7820>
                  <Vector src={VectorImage} loading='lazy' alt={"Vector"}/>
                  <Vector1 src={Vector1Image} loading='lazy' alt={"Vector"}/>
                  <Vector2 src={Vector2Image} loading='lazy' alt={"Vector"}/>
                  <Vector3 src={Vector3Image} loading='lazy' alt={"Vector"}/>
                  <Vector4 src={Vector4Image} loading='lazy' alt={"Vector"}/>
                  <Vector5 src={Vector5Image} loading='lazy' alt={"Vector"}/>
                </Group7820>
              </Group7795>
            </Frame7826>
            <Group6680>
              <Group6052>
                <Investing>
                  {`Investing`}
                </Investing>
                <Q24Increase>
                  {`24% Increase`}
                </Q24Increase>
              </Group6052>
              <Q82>
                {`82%`}
              </Q82>
            </Group6680>
          </Frame6681>
        </Group6695>
        <Group6699>
          <Rectangle241>
          </Rectangle241>
          <Frame66811>
            <Frame78261>
              <Rectangle251>
              </Rectangle251>
              <Group77951>
                <Vector6 src={Vector6Image} loading='lazy' alt={"Vector"}/>
                <Vector7 src={Vector7Image} loading='lazy' alt={"Vector"}/>
                <Vector8 src={Vector8Image} loading='lazy' alt={"Vector"}/>
                <Vector9 src={Vector9Image} loading='lazy' alt={"Vector"}/>
              </Group77951>
            </Frame78261>
            <Group66801>
              <Group60521>
                <Saving>
                  {`Saving`}
                </Saving>
                <Q12Decrease>
                  {`12% Decrease`}
                </Q12Decrease>
              </Group60521>
              <Q52>
                {`52%`}
              </Q52>
            </Group66801>
          </Frame66811>
        </Group6699>
        <Group6700>
          <Rectangle242>
          </Rectangle242>
          <Frame66812>
            <Frame78262>
              <Rectangle252>
              </Rectangle252>
              <Group77952>
                <Group7809>
                  <Vector10 src={Vector10Image} loading='lazy' alt={"Vector"}/>
                  <Vector11 src={Vector11Image} loading='lazy' alt={"Vector"}/>
                  <Vector12 src={Vector12Image} loading='lazy' alt={"Vector"}/>
                  <Vector13 src={Vector13Image} loading='lazy' alt={"Vector"}/>
                </Group7809>
              </Group77952>
            </Frame78262>
            <Group66802>
              <Group60522>
                <Budgeting>
                  {`Budgeting`}
                </Budgeting>
                <Q7Decrease>
                  {`7% Decrease`}
                </Q7Decrease>
              </Group60522>
              <Q12>
                {`12%`}
              </Q12>
            </Group66802>
          </Frame66812>
        </Group6700>
      </Frame6699>
      <Frame16>
        <Frame15>
          <Rectangle10>
          </Rectangle10>
          <DreamScore>
            {`DreamScore`}
          </DreamScore>
        </Frame15>
        <Frame14>
          <Rectangle11>
          </Rectangle11>
          <Review>
            {`Review`}
          </Review>
        </Frame14>
      </Frame16>
      <Frame6700>
        <Frame20>
          <Frame19>
            <Ellipse3 src={Ellipse3Image} loading='lazy' alt={"Ellipse 3"}/>
            <Ellipse4 src={Ellipse4Image} loading='lazy' alt={"Ellipse 4"}/>
            <Ellipse5 src={Ellipse5Image} loading='lazy' alt={"Ellipse 5"}/>
          </Frame19>
          <Q81>
            {`81`}
          </Q81>
          <Q7>
            {`+7`}
          </Q7>
        </Frame20>
        <Frame18>
          <YourDreamscore>
            {`Your Dreamscore?`}
          </YourDreamscore>
          <Great>
            {`Great`}
          </Great>
        </Frame18>
        <WhatIsDreamscore>
          {`What is Dreamscore?`}
        </WhatIsDreamscore>
      </Frame6700>
      <GoalProgress>
        {`Goal Progress`}
      </GoalProgress>
      <Frame7834>
        <ProgressBarW75>
          <Background>
          </Background>
          <ProgressBarW751>
          </ProgressBarW751>
        </ProgressBarW75>
        <Frame7833>
          <Q80>
            {`80%`}
          </Q80>
          <Progress>
            <Q119>
              {`$200 Remaining`}
            </Q119>
          </Progress>
        </Frame7833>
      </Frame7834>
      <Header/>
      <Navigation/>
    </DreamScoreMainPage1>);

  }

export default DreamScoreMainPage;

  